var x=190;
var y=290;
var x1=190;
var y1=270;
var x2=60;
var y2=245;
var x3=190;
var y3=230;

var mouseShapeX;
var mouseShapeY;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  fill(206, 143, 110)
  ellipse(x,y,300,110)
  x=x+1;
  y=y-1;
  
  fill(111, 78, 55)
  ellipse(x1,y1,280,90)
  x1=x1-1;
  y1=y1+1;
  
  fill(255, 191, 0)
  rect(x2,y2,260,50)
  x2=x2+1;
  y2=y2+1;
  
  fill(206, 143, 110)
  ellipse(x3,y3,300,110)
  x3=x3-1;
  y3=y3-1;
  
  fill(255, 222, 173)
  circle(mouseShapeX,mouseShapeY,10)
  /*
  circle(100,215,10)
  circle(140,245,10)
  circle(190,200,10)
  circle(270,225,10)
  circle(220,250,10)
  */
  
  fill(68, 176, 175)
  textSize(30);
  text('Cheeseburger',10,30)
  text('Tyler Rolfe',250,390)
}

function mouseClicked()
{
    mouseShapeX = mouseX;
    mouseShapeY = mouseY;
}
