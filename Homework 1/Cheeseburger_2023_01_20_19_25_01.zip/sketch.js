function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  fill(206, 143, 110)
  ellipse(190,290,300,110)
  fill(111, 78, 55)
  ellipse(190,270,280,90)
  fill(255, 191, 0)
  rect(60,245,260,50)
  fill(206, 143, 110)
  ellipse(190,230,300,110)
  fill(255, 222, 173)
  circle(100,215,10)
  circle(140,245,10)
  circle(190,200,10)
  circle(270,225,10)
  circle(220,250,10)
}

